// eslint-disable-next-line @typescript-eslint/no-unused-vars
import styles from './app.module.css';
import { createBrowserRouter, RouterProvider } from 'react-router-dom';
import {NotFound} from '@shared/components';
import Dashboard from './pages/Dashboard/Dashboard';
import Home from './pages/Home/Home';
import {MainLayout} from '@shared/layouts';

// import NxWelcome from './nx-welcome';
const router = createBrowserRouter(
  [
    {
      path:'/',
      element: <MainLayout />,
      errorElement: <NotFound />,
      children: [
        { index: true, element: <Home />}, 
        { path:'/dashboard', element: <Dashboard />},
      ],
    },
  ]
);

export function App() {
  return <RouterProvider router={router} />;
}

export default App;
