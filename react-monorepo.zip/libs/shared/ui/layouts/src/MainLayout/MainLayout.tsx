import styles from './MainLayout.module.css';
import {Outlet} from 'react-router-dom';

/* eslint-disable-next-line */
export interface MainLayoutProps {}

export function MainLayout(props: MainLayoutProps) {
  return (
    <div className={styles['container']}>
      <h1>Welcome to MainLayout!</h1>
      <Outlet />
    </div>
  );
}

export default MainLayout;
