import { render } from '@testing-library/react';

import SampleComponentProps from './SampleComponent';

describe('SampleComponentProps', () => {
  it('should render successfully', () => {
    const { baseElement } = render(<SampleComponentProps />);
    expect(baseElement).toBeTruthy();
  });
});
